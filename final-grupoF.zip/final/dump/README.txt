- Arquivos:
    schema.sql: Contém a definição dos esquemas das tabelas do banco de dados MySQL
    data.sql: Contém os dados que serão inseridos no banco de dados

- Para popular o banco de dados, primeiro executar o arquivo schema.sql e depois o arquivo data.sql. Será criado um novo database chamado mc536.
